CREATE PROCEDURE myproce()
  begin
Select fname,phone from users;
end;
